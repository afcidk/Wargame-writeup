<?php

// database config
define('DB_USER', '..............');
define('DB_PASS', '..............');
define('DB_HOST', 'host=localhost');
define('DB_NAME', '..............');

// redis config
define('REDIS_HOST', 'localhost');
define('REDIS_PORT', 25566);

// define flag
define('FLAG', 'Sorry you have to read config.php from file system to obtain this flag');

$c_hardness = 5; // how many proof of work leading zeros
